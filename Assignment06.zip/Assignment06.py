# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  November 11, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/11/2018, Created starting template
#   Zeynep Yazicioglu, Added code to complete assignment 6
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

class TaskProcessor(object):
    'Class that manages list of tasks'

    def readTodoFile(objFileName):
        'Read the task data into a list of tasks'
        lstTable = []
        dicRow = {}
        with open(objFileName, mode='rt') as file:
            for line in file:
                parts = line.strip("\n").split(",")
                if len(parts) < 2:
                    continue
                dicRow["Task"] = parts[0]
                dicRow["Priority"] = parts[1]
                lstTable.append(dicRow)
                dicRow = {}

        return lstTable

    def getItemDescriptionFromDictionary(dict):
        'Print a task in string format'
        return "Task: {0}, Priority: {1}".format(dict["Task"], dict["Priority"])

    def readTaskIntoDictionary():
        'Read a task from the user'
        taskName = str(input("Enter a task name:"))
        taskPriority = str(input("Enter the priority for task {0}:".format(taskName)))
        dicRow = {}
        dicRow["Task"] = taskName
        dicRow["Priority"] = taskPriority
        return dicRow

    def removeTaskFromList(lstTable):
        taskName = str(input("Enter the task to remove:"))
        for dic in lstTable:
            if dic["Task"] == taskName:
                lstTable.remove(dic)
                break

    def saveTaskListToFile(lstTable, objFileName):
        with open(objFileName, mode='wt') as file:
            for dic in lstTable:
                file.write("{0},{1}\n".format(dic["Task"], dic["Priority"]))

    objFileName = "Todo.txt"
    strData = ""


    # Step 1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"

    lstTable = readTodoFile(objFileName)

    # Step 2 - Display a menu of choices to the user
    while (True):
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        print()  # adding a new line

        # Step 3 -Show the current items in the table
        if (strChoice.strip() == '1'):
            for dict in lstTable:
                print(getItemDescriptionFromDictionary(dict))
            continue
        # Step 4 - Add a new item to the list/Table
        elif (strChoice.strip() == '2'):
            lstTable.append(readTaskIntoDictionary())
            continue
        # Step 5 - Remove a new item to the list/Table
        elif (strChoice == '3'):
            removeTaskFromList(lstTable)
            continue
        # Step 6 - Save tasks to the ToDo.txt file
        elif (strChoice == '4'):
            saveTaskListToFile(lstTable, objFileName)
            continue
        elif (strChoice == '5'):
            break  # and Exit the program